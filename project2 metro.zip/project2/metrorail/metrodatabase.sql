--CREATE DATABASE metroRail 
use metroRail
create TABLE tblMetro (
    metroId int IDENTITY PRIMARY KEY,
    metroName NVARCHAR(30)
)
GO
--Insert Data Into tblMetro

insert into tblMetro (metroName) VALUES ('Sonar Bangla'),('Lal Sobuj'),('Bonolota'),('Padma')
GO
--create table tblStoppages

CREATE TABLE tblStoppages(
    stoppageId int IDENTITY PRIMARY KEY,
    stoppage NVARCHAR(40)
)
GO
--Insert Into tblStoppages

insert into tblStoppages (stoppage) VALUES('Uttra TO Cantonment'),('Uttra To Agargaon'),('Uttra To Mirpur'),('Uttra To Bangla-motor'),('Uttra TO Motijil'),('Motijil To Uttra')
GO
SELECT *from tblStoppages

--Create table tblBookTicket

CREATE TABLE tblBookTicket(
    ticketId int IDENTITY PRIMARY KEY,
    customerName NVARCHAR(30),
    email NVARCHAR(30),
    stoppage NVARCHAR(50),
    KM int not null,
    ticketFare as((20-KM)*20),
    metroId int REFERENCES tblMetro(metroId)
)
GO
select*from tblBookTicket
GO
--Create Table tblLink

CREATE TABLE tblLink(
    linkId int IDENTITY ,
    ticketId int  REFERENCES tblBookTicket(ticketId),
    stoppageId int REFERENCES tblStoppages(stoppageId),
    metroId int REFERENCES tblMetro(metroId),
    PRIMARY KEY(ticketId,stoppageId,metroId,linkId)
)
GO
select*from tblMetro

select m.metroName,bt.ticketId,bt.customerName,bt.email,bt.stoppage,bt.ticketFare from tblMetro m inner join tblBookTicket bt on m.metroId=bt.metroId
create TABLE register(
    regId int IDENTITY PRIMARY key,
    userName NVARCHAR(90),
    userPassword NVARCHAR(30),
    email NVARCHAR(50),
    contact NVARCHAR(30)
)
go

drop table register
insert into register (userName,userPassword) VALUES('imam','imammasum')
select *from  register 