﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace metrorail
{
    public partial class loginp : Form
    {
        SqlConnection con = new SqlConnection("Data Source=IMAM;Initial Catalog=metroRail; Integrated Security=True;");
        public loginp()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlDataAdapter sda = new SqlDataAdapter("Select * from register where userName='"+txtname.Text+"' and userPassword='"+txtpassword.Text+"'",con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                FrameMaster ft = new FrameMaster();
                ft.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Invalid Username or password!!!", "Warning", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            }
        }

        private void lblnotregistered_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            formregister fr = new formregister();
            fr.Show();
            this.Hide();
        }
    }
}
