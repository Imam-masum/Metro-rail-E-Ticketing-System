﻿
namespace metrorail
{
    partial class FrameMaster
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.purchaseETicketToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.purchaseETicketToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.viewTicketHistoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateDeleteToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.reportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportForTicketHistoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportForAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logInToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.purchaseTicketToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewHistoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.signUpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.updateDeleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem1,
            this.purchaseETicketToolStripMenuItem,
            this.reportToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 33);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem1
            // 
            this.fileToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem1});
            this.fileToolStripMenuItem1.Name = "fileToolStripMenuItem1";
            this.fileToolStripMenuItem1.Size = new System.Drawing.Size(54, 29);
            this.fileToolStripMenuItem1.Text = "File";
            // 
            // exitToolStripMenuItem1
            // 
            this.exitToolStripMenuItem1.Name = "exitToolStripMenuItem1";
            this.exitToolStripMenuItem1.Size = new System.Drawing.Size(141, 34);
            this.exitToolStripMenuItem1.Text = "Exit";
            this.exitToolStripMenuItem1.Click += new System.EventHandler(this.exitToolStripMenuItem1_Click);
            // 
            // purchaseETicketToolStripMenuItem
            // 
            this.purchaseETicketToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.purchaseETicketToolStripMenuItem1,
            this.viewTicketHistoryToolStripMenuItem,
            this.updateDeleteToolStripMenuItem1});
            this.purchaseETicketToolStripMenuItem.Image = global::metrorail.Properties.Resources.download1;
            this.purchaseETicketToolStripMenuItem.Name = "purchaseETicketToolStripMenuItem";
            this.purchaseETicketToolStripMenuItem.Size = new System.Drawing.Size(160, 29);
            this.purchaseETicketToolStripMenuItem.Text = "Metro Service";
            // 
            // purchaseETicketToolStripMenuItem1
            // 
            this.purchaseETicketToolStripMenuItem1.Image = global::metrorail.Properties.Resources.eticket;
            this.purchaseETicketToolStripMenuItem1.Name = "purchaseETicketToolStripMenuItem1";
            this.purchaseETicketToolStripMenuItem1.Size = new System.Drawing.Size(263, 34);
            this.purchaseETicketToolStripMenuItem1.Text = "Purchase E-Ticket";
            this.purchaseETicketToolStripMenuItem1.Click += new System.EventHandler(this.purchaseETicketToolStripMenuItem1_Click);
            // 
            // viewTicketHistoryToolStripMenuItem
            // 
            this.viewTicketHistoryToolStripMenuItem.Image = global::metrorail.Properties.Resources.ticket;
            this.viewTicketHistoryToolStripMenuItem.Name = "viewTicketHistoryToolStripMenuItem";
            this.viewTicketHistoryToolStripMenuItem.Size = new System.Drawing.Size(263, 34);
            this.viewTicketHistoryToolStripMenuItem.Text = "View Ticket History";
            this.viewTicketHistoryToolStripMenuItem.Click += new System.EventHandler(this.viewTicketHistoryToolStripMenuItem_Click);
            // 
            // updateDeleteToolStripMenuItem1
            // 
            this.updateDeleteToolStripMenuItem1.Image = global::metrorail.Properties.Resources.update;
            this.updateDeleteToolStripMenuItem1.Name = "updateDeleteToolStripMenuItem1";
            this.updateDeleteToolStripMenuItem1.Size = new System.Drawing.Size(263, 34);
            this.updateDeleteToolStripMenuItem1.Text = "Update/Delete";
            this.updateDeleteToolStripMenuItem1.Click += new System.EventHandler(this.updateDeleteToolStripMenuItem1_Click);
            // 
            // reportToolStripMenuItem
            // 
            this.reportToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.reportForTicketHistoryToolStripMenuItem,
            this.reportForAllToolStripMenuItem});
            this.reportToolStripMenuItem.Image = global::metrorail.Properties.Resources.view4;
            this.reportToolStripMenuItem.Name = "reportToolStripMenuItem";
            this.reportToolStripMenuItem.Size = new System.Drawing.Size(105, 29);
            this.reportToolStripMenuItem.Text = "Report";
            // 
            // reportForTicketHistoryToolStripMenuItem
            // 
            this.reportForTicketHistoryToolStripMenuItem.Image = global::metrorail.Properties.Resources.view4;
            this.reportForTicketHistoryToolStripMenuItem.Name = "reportForTicketHistoryToolStripMenuItem";
            this.reportForTicketHistoryToolStripMenuItem.Size = new System.Drawing.Size(307, 34);
            this.reportForTicketHistoryToolStripMenuItem.Text = "Report for Ticket History";
            this.reportForTicketHistoryToolStripMenuItem.Click += new System.EventHandler(this.reportForTicketHistoryToolStripMenuItem_Click);
            // 
            // reportForAllToolStripMenuItem
            // 
            this.reportForAllToolStripMenuItem.Image = global::metrorail.Properties.Resources.view4;
            this.reportForAllToolStripMenuItem.Name = "reportForAllToolStripMenuItem";
            this.reportForAllToolStripMenuItem.Size = new System.Drawing.Size(307, 34);
            this.reportForAllToolStripMenuItem.Text = "Report For All";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(54, 29);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(141, 34);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // logInToolStripMenuItem
            // 
            this.logInToolStripMenuItem.Image = global::metrorail.Properties.Resources.eticket;
            this.logInToolStripMenuItem.Name = "logInToolStripMenuItem";
            this.logInToolStripMenuItem.Size = new System.Drawing.Size(166, 29);
            this.logInToolStripMenuItem.Text = "Metro E-Ticket";
            this.logInToolStripMenuItem.Click += new System.EventHandler(this.logInToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(267, 6);
            // 
            // purchaseTicketToolStripMenuItem
            // 
            this.purchaseTicketToolStripMenuItem.Image = global::metrorail.Properties.Resources.ticket;
            this.purchaseTicketToolStripMenuItem.Name = "purchaseTicketToolStripMenuItem";
            this.purchaseTicketToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.purchaseTicketToolStripMenuItem.Text = "Purchase Ticket";
            this.purchaseTicketToolStripMenuItem.Click += new System.EventHandler(this.purchaseTicketToolStripMenuItem_Click);
            // 
            // viewHistoryToolStripMenuItem
            // 
            this.viewHistoryToolStripMenuItem.Image = global::metrorail.Properties.Resources.view4;
            this.viewHistoryToolStripMenuItem.Name = "viewHistoryToolStripMenuItem";
            this.viewHistoryToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.viewHistoryToolStripMenuItem.Text = "View  Ticket History";
            this.viewHistoryToolStripMenuItem.Click += new System.EventHandler(this.viewHistoryToolStripMenuItem_Click);
            // 
            // signUpToolStripMenuItem
            // 
            this.signUpToolStripMenuItem.Image = global::metrorail.Properties.Resources.download1;
            this.signUpToolStripMenuItem.Name = "signUpToolStripMenuItem";
            this.signUpToolStripMenuItem.Size = new System.Drawing.Size(105, 29);
            this.signUpToolStripMenuItem.Text = "Report";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(16, 29);
            // 
            // updateDeleteToolStripMenuItem
            // 
            this.updateDeleteToolStripMenuItem.Image = global::metrorail.Properties.Resources.update;
            this.updateDeleteToolStripMenuItem.Name = "updateDeleteToolStripMenuItem";
            this.updateDeleteToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.updateDeleteToolStripMenuItem.Text = "Update/Delete";
            // 
            // FrameMaster
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.BackgroundImage = global::metrorail.Properties.Resources.mainphoto;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FrameMaster";
            this.Text = "FrameMaster";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logInToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem signUpToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem purchaseTicketToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewHistoryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem updateDeleteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem purchaseETicketToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem purchaseETicketToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem viewTicketHistoryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateDeleteToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem reportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportForTicketHistoryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportForAllToolStripMenuItem;
    }
}