﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace metrorail
{
    public partial class FrameMaster : Form
    {
        public FrameMaster()
        {
            InitializeComponent();
        }

        private void logInToolStripMenuItem_Click(object sender, EventArgs e)
        {
           

        }

        private void purchaseTicketToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void viewHistoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void purchaseETicketToolStripMenuItem1_Click(object sender, EventArgs e)
        {

            Form1 f1 = new Form1();
            f1.MdiParent = this;
            f1.Show();
        }

        private void viewTicketHistoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ticketDetils td = new ticketDetils();
            td.MdiParent = this;
            td.Show();
        }

        private void updateDeleteToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            
            
        }

        private void reportForTicketHistoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmTicketDetils td = new frmTicketDetils();
            td.MdiParent = this;
            td.Show();
        }
    }
}
