﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace metrorail
{
    public partial class ticketDetils : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=IMAM;Initial Catalog=metroRail; Integrated Security=True;");
        public ticketDetils()
        {
            InitializeComponent();
        }

        private void ticketDetils_Load(object sender, EventArgs e)
        {
            loadGrid();
        }
        private void loadGrid()
        {
            SqlDataAdapter sda = new SqlDataAdapter("select m.metroId, m.metroName,bt.ticketId,bt.customerName,bt.email,bt.stoppage,bt.ticketFare,bt.purchaseDate from tblMetro m inner join tblBookTicket bt on m.metroId=bt.metroId ;select @@IDENTITY", con);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }
    }
}
