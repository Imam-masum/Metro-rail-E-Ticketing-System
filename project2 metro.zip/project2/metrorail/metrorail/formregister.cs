﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace metrorail
{
    public partial class formregister : Form
    {
        SqlConnection con = new SqlConnection("Data Source=IMAM;Initial Catalog=metroRail; Integrated Security=True;");
        public formregister()
        {
            InitializeComponent();
        }

        private void btnregistered_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandText = "Insert Into register(userName,userPassword,email,contact) values(@n,@p,@e,@c)";
            cmd.Parameters.AddWithValue("@n", txtName.Text);
            cmd.Parameters.AddWithValue("@p", txtpassword.Text);
            cmd.Parameters.AddWithValue("@e", txtemail.Text);
            cmd.Parameters.AddWithValue("@c",txtcontact.Text);
          
            if (cmd.ExecuteNonQuery() > 0)
            {
                MessageBox.Show("Data Saved Sucessfully");
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            loginp lp = new loginp();
            lp.Show();
            this.Hide();
        }
    }
}
