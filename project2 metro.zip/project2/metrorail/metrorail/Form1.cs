﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace metrorail
{
    public partial class Form1 : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=IMAM;Initial Catalog=metroRail; Integrated Security=True;");

        public Form1()
        {
            InitializeComponent();
        }
        public void displaydata()
        {

            try
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select * from tblBookTicket";
                cmd.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                sda.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            loadCombo();
            displaydata();

        }
        private void loadCombo()
        {
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select stoppageId,stoppage from tblStoppages", con);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            cmbstoppage.DataSource = ds.Tables[0];
            cmbstoppage.DisplayMember = "stoppage";
            cmbstoppage.ValueMember = "stoppageId";

            SqlDataAdapter sda2 = new SqlDataAdapter("Select metroId,metroName from tblMetro", con);
            DataSet ds2 = new DataSet();
            sda2.Fill(ds2);
            cmbmetroid.DataSource = ds2.Tables[0];
            cmbmetroid.DisplayMember = "metroName";
            cmbmetroid.ValueMember = "metroId";

            con.Close();
        }
        private void AllClear()
        {
            txtId.Text = "";
            txtName.Text = "";
            txtEmail.Text = "";
            txtkm.Text = "";
            cmbstoppage.Text = "";
            cmbmetroid.Text = "";
            pdatetime.Value = DateTime.Now;
        }


        private void btnBook_Click(object sender, EventArgs e)
        {

            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandText = "Insert Into tblBookTicket(customerName,email,stoppage,KM,metroId,purchaseDate) values(@n,@e,@s,@k,@m,@pd)";
            cmd.Parameters.AddWithValue("@n", txtName.Text);
            cmd.Parameters.AddWithValue("@e", txtEmail.Text);
            cmd.Parameters.AddWithValue("@s", cmbstoppage.SelectedValue);
            cmd.Parameters.AddWithValue("@k", txtkm.Text);
            cmd.Parameters.AddWithValue("@m", cmbmetroid.SelectedValue.ToString());
            cmd.Parameters.AddWithValue("@pd", pdatetime.Value);
            if (cmd.ExecuteNonQuery() > 0)
            {
                MessageBox.Show("Data Saved Sucessfully");
            }

            con.Close();
            AllClear();
            displaydata();
        }


        private void btnView_Click(object sender, EventArgs e)
        {


        }

        private void btnView_Click_1(object sender, EventArgs e)
        {

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {


            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = "Update tblBookTicket set customerName=@n,email=@e,stoppage=@s,KM=@k,metroId=@m,purchaseDate=@pd where ticketId=@i";


                cmd.Parameters.AddWithValue("@i", txtId.Text);
                cmd.Parameters.AddWithValue("@n", txtName.Text);
                cmd.Parameters.AddWithValue("@e", txtEmail.Text);
                cmd.Parameters.AddWithValue("@s", cmbstoppage.SelectedValue.ToString());
                cmd.Parameters.AddWithValue("@k", txtkm.Text);
                cmd.Parameters.AddWithValue("@m", cmbmetroid.SelectedValue.ToString());
                cmd.Parameters.AddWithValue("@pd", pdatetime.Value);
               if( cmd.ExecuteNonQuery() > 0) { 
                
                MessageBox.Show("data updated successfully");
                }
                con.Close();
                AllClear();
                displaydata();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
           
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandText = "delete from tblBookTIcket where ticketId=@i";
            cmd.Parameters.AddWithValue("@i", txtId.Text);
            con.Open();
           if (cmd.ExecuteNonQuery() > 0) { 
           
            MessageBox.Show("data deleted successfully");
            }
            con.Close();
            AllClear();
            displaydata();

        }



        private void btnSearch_Click(object sender, EventArgs e)
        {
            SqlDataAdapter sda = new SqlDataAdapter("select ticketId,customerName,email,stoppage,KM,metroId,purchaseDate from tblBookTicket WHERE ticketId="+txtId.Text+"", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                txtName.Text = dt.Rows[0]["customerName"].ToString();
                txtEmail.Text = dt.Rows[0]["email"].ToString();
                txtkm.Text= dt.Rows[0]["KM"].ToString();
                cmbmetroid.SelectedValue = dt.Rows[0]["metroId"].ToString();
                cmbstoppage.SelectedValue = dt.Rows[0]["stoppage"].ToString() ;
                pdatetime.Text= dt.Rows[0]["purchaseDate"].ToString();
                cmbmetroid.SelectedValue= dt.Rows[0]["metroId"].ToString();
            }
        }
    }



}




